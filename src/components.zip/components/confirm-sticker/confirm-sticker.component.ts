import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-sticker',
  templateUrl: './confirm-sticker.component.html',
  styleUrls: ['./confirm-sticker.component.scss']
})
export class ConfirmStickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
